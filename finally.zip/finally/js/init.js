(function($){
  $(function(){
 $('.button-collapse').sideNav({
    	menuWidth:200
    }); 
    $('.button-collapse').sideNav();
    $('.parallax').parallax();
  $('.grid-container').gridQuote();
  }); // end of document ready
})(jQuery); // end of jQuery name space
