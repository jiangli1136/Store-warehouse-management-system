 $(document).ready(function(){
      	  	$('.button-collapse').sideNav({
    	menuWidth:200
    }); 
    });
$(function(){
	setInterval("time()", 1000);
	getMsg();
	fitcube();
});

window.onresize = function () {fitcube();}
function getMsg(){
	var slogan=[
	"给时光与生命<br>给岁月与文明",
	"愿与最重要之人能再度相会",
	"隐约雷鸣,阴霾天空<br>但盼风雨来,能留你在此",
	"隐约雷鸣,阴霾天空<br>即使天无雨,我亦留此地 ",
	"失去只是一瞬,一瞬的疏忽",
	"梦里不觉秋已深<br>余情岂是为他人",
	"我要用什么样的速度才能与你相遇？",
	"时间带着明显的恶意<br>缓缓的在我身上流逝",
	"我们仰望着同一片天空却看向不同的地方",
	"哀而不伤<br>延绵一生"
	];
	var r = random(0,slogan.length-1);
	$("#slogan").html(slogan[r]);
}
function random(Min,Max){
      var Range = Max - Min;
      var Rand = Math.random();
      var num = Min + Math.round(Rand * Range);
      return num;
}
function fitcube(){
	var el = $('.el span').width();
	$('.el span').css('height',el+'px');
}
//获取时间，用时间的数值加#作为背景
function time() {
	var time = '#' + (new Date()).toTimeString().match(/\d{2}:\d{2}:\d{2}/)[0].replace(/:/g, '');
	$('.time').text(time);
	$('.background').css('background-color', time);
};
